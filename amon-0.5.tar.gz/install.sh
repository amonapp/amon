#!/bin/sh

python setup.py install
sudo rm -rf Amon.egg-info dist build 
