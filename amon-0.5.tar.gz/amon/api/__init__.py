from amon.api.log import Log
from amon.api.exception import Exception

log = Log()
exception = Exception()
