from os.path import join, abspath, dirname

PROJECT_ROOT = abspath(dirname(__file__))
TEMPLATES_DIR =  join(PROJECT_ROOT, 'templates')
