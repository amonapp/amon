http_path = "/"
css_dir = "css"
sass_dir = "sass"

# You can select your preferred output style here (can be overridden via the command line):
# output_style = :expanded or :nested or :compact or :compressed


# To disable debugging comments that display the original location of your selectors. Uncomment:
line_comments = false

