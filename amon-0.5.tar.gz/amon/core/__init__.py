from amon.core.settings import Settings

settings = Settings()
